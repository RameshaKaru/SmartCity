
-- -----------------------------------------------------
-- Table `senseme_DEVICE`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS senseme_DEVICE (
  senseme_DEVICE_ID VARCHAR(45) NOT NULL ,
  DEVICE_NAME VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (senseme_DEVICE_ID) );

